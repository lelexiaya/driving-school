package com.nuc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nuc.model.MemberShipEntity;
import com.nuc.model.PageBean;
import com.nuc.model.RoleEntity;
import com.nuc.model.UserEntity;
import com.nuc.service.MemberShipService;
import com.nuc.service.RoleService;
import com.nuc.service.UploadService;
import com.nuc.service.UserService;
import com.nuc.util.ConstantUtils;
import com.nuc.util.ResponseUtil;
import com.nuc.util.UploadUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
* @author HowardAllen
* @version 2019年4月6日 上午12:25:27
* Disc 
*/

@Controller
@RequestMapping("/user")
public class UserController {

    private static  final Logger  logger =  LoggerFactory.getLogger(UserController.class);
    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private MemberShipService memberShipService;
    
    @Autowired
    private UploadService uploadService;

    /**
     * desc 用户登录
     * @param requset
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/login")
    public String login(HttpServletRequest requset, HttpServletResponse response)throws Exception{
        try {
            String userName = requset.getParameter("userName");
            String password=requset.getParameter("password");
            String roleId=requset.getParameter("roleId");
            
            Map<String,Object> map = new HashMap<String, Object>();
            map.put("username",userName);
            map.put("password",password);
            map.put("roleId",roleId);
            
            MemberShipEntity memberShipEntity = memberShipService.login(map);
            JSONObject result = new JSONObject();
            if(memberShipEntity == null){
                result.put("success", false);
                result.put("errorInfo", "用户名或者密码错误！");
            }else{
                result.put("success", true);
                requset.getSession().setAttribute("currentMemberShip", memberShipEntity);
            }
            ResponseUtil.write(response, result);
        }catch (Exception e){
            logger.error("登录失败" + e.getMessage());
        }

        return null;
    }

    /**
     * desc 分页条件查询用户
     * @param page
     * @param rows
     * @param userEntity
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/list")
    public String list(
    		@RequestParam(value="page",required=false) String page, 
    		@RequestParam(value="rows",required=false) String rows, 
    		UserEntity userEntity,
    		HttpServletResponse response)throws Exception{
    	
        PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
        
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("username", userEntity.getUsername());
        map.put("realName",userEntity.getRealName());
        map.put("collage",userEntity.getCollage());
        map.put("classId",userEntity.getClassId());
        map.put("start", pageBean.getStart());
        map.put("size", pageBean.getPageSize());
        
        List<UserEntity> userEntityList = userService.find(map);
        for(UserEntity entity : userEntityList) {
        	if(ConstantUtils.ONE_STR.equals(entity.getSex())) {
        		entity.setSex(ConstantUtils.MAN_STR);
        	}
        	else if(ConstantUtils.ZERO_STR.equals(entity.getSex())) {
        		entity.setSex(ConstantUtils.WOMAN_STR);
        	}
        }
        Long total = userService.getTotal(map);
        
        JSONObject result = new JSONObject();
        JSONArray jsonArray = JSONArray.fromObject(userEntityList);
        result.put("rows", jsonArray);
        result.put("total", total);
        ResponseUtil.write(response, result);
        
        return null;
    }


    /**
     * 分页条件查询用户以及用户所有的角色
     * @param page
     * @param rows
     * @param userEntity
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/listWithGroups")
    public String listWithGroups(
    		@RequestParam(value="page",required=false) String page,
    		@RequestParam(value="rows",required=false) String rows,
    		UserEntity userEntity,
    		HttpServletResponse response)throws Exception{
    	
        PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("username", userEntity.getUsername());
        map.put("realName",userEntity.getRealName());
        map.put("collage",userEntity.getCollage());
        map.put("classId",userEntity.getClassId());

        map.put("start", pageBean.getStart());
        map.put("size", pageBean.getPageSize());
        
        List<UserEntity> userList = userService.find(map);
        for(UserEntity user : userList){
            StringBuffer groups = new StringBuffer();
            List<RoleEntity> groupList = roleService.findByUserId(user.getUserId());
            
            if(ConstantUtils.ONE_STR.equals(user.getSex())) {
            	user.setSex(ConstantUtils.MAN_STR);
        	}
        	else if(ConstantUtils.ZERO_STR.equals(user.getSex())) {
        		user.setSex(ConstantUtils.WOMAN_STR);
        	}
            
            for(RoleEntity g : groupList){
                groups.append(g.getRoleName() + ",");
            }
            if(groups.length()>0){
                user.setGroups(groups.deleteCharAt(groups.length()-1).toString()); // 去掉最后一个逗号
            }else{
                user.setGroups(groups.toString());
            }
        }
        
        Long total = userService.getTotal(map);
        JSONObject result=new JSONObject();
        JSONArray jsonArray=JSONArray.fromObject(userList);
        result.put("rows", jsonArray);
        result.put("total", total);
        ResponseUtil.write(response, result);
        
        return null;
    }

    /**
     * desc 添加或者修用户
     * @param user
     * @param response
     * @param flag 1 添加  2修改
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/save", method=RequestMethod.POST)
    public String save(
    		UserEntity user, 
    		HttpServletRequest request,
    		HttpServletResponse response, 
    		Integer flag) throws Exception{
    	
        int resultTotal = 0; // 操作的记录条数
        
        String sex = request.getParameter("sexRadio");
        user.setSex(sex);
        
        if(flag == ConstantUtils.ONE_NUMBER){
        	user.setPassword(user.getCardId().substring(user.getCardId().length() - 6));
            resultTotal = userService.add(user);
        }else{
            resultTotal = userService.update(user);
        }
        
        JSONObject result=new JSONObject();
        if(resultTotal > 0){
            result.put("success", true);
        }else{
            result.put("success", false);
        }
        
        ResponseUtil.write(response, result);
        return null;
    }

    /**
     * desc 删除用户
     * @param ids
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/delete")
    public String delete(
    		@RequestParam(value="ids")String ids, 
    		HttpServletResponse response) throws Exception{
    	
        String []idsStr=ids.split(",");
        for(int i=0;i<idsStr.length;i++){
            userService.delete(idsStr[i]);
        }
        
        JSONObject result=new JSONObject();
        result.put("success", true);
        ResponseUtil.write(response, result);
        
        return null;
    }

    /**
     * desc 判断是否存在指定用户名
     * @param userName
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/existUsername")
    public String existUserName(String username, HttpServletResponse response) throws Exception{
    	
        JSONObject result = new JSONObject();
        
        if(userService.findByUsername(username) == null){
            result.put("exist", false);
        }else{
            result.put("exist", true);
        }
        ResponseUtil.write(response, result);
        
        return null;
    }
    
    /**
     * desc 
     * @param response
     * @return
     */
    @RequestMapping("getCollageList")
    public String getCollageList(HttpServletResponse response) {
    	
        JSONArray array = new JSONArray();
        
        try {
            List<UserEntity> list = userService.getCollageList(null);
            JSONArray jsonArray = JSONArray.fromObject(list);
            array.addAll(jsonArray);

            ResponseUtil.write(response, array);
        } catch (Exception e) {
            logger.error("对不起 发生未知错误" + e.getMessage());
        }
        return null;
	}
    
    /**
     * desc 
     * @param response
     * @return
     */
    @RequestMapping("getClassIdList")
    public String getClassIdList(HttpServletResponse response) {
    	
    	JSONArray array = new JSONArray();
    	
    	try {
    		List<UserEntity> list = userService.getClassIdList(null);
    		JSONArray jsonArray = JSONArray.fromObject(list);
    		array.addAll(jsonArray);
    		
    		ResponseUtil.write(response, array);
    	} catch (Exception e) {
    		logger.error("对不起 发生未知错误" + e.getMessage());
    	}
    	return null;
    }

    /**
     * desc 修改用户密码
     * @param id
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/modifyPassword")
    public String modifyPassword(String id, 
    		String newPassword, 
    		HttpServletResponse response) throws Exception{
    	
        UserEntity user = new UserEntity();
        user.setUserId(Integer.valueOf(id));
        user.setPassword(newPassword);
        
        int resultTotal = userService.update(user);
        
        JSONObject result=new JSONObject();
        if(resultTotal>0){
            result.put("success", true);
        }else{
            result.put("success", false);
        }
        
        ResponseUtil.write(response, result);
        return null;
    }

    /**
     * desc 用户注销
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping("/logout")
    public String logout(HttpSession session)throws Exception{
        session.invalidate();
        return "redirect:/login";
    }



    /**
     * 获取教师信息列表
     * @param response
     * @return
     */
    @RequestMapping("getTeacherInfoList")
    public String getTeacherInfoList(HttpServletResponse response) {
    	
    	JSONArray array = new JSONArray();
    	
    	try {
    		String roleName = ConstantUtils.STR_CH_TEACHER;
    		List<UserEntity> list = userService.getUserInfoByRoleName(roleName);
    		JSONArray jsonArray = JSONArray.fromObject(list);
    		array.addAll(jsonArray);
    		
    		ResponseUtil.write(response, array);
    	} catch (Exception e) {
    		logger.error("对不起 发生未知错误" + e.getMessage());
    	}
    	return null;
    }

    @RequestMapping("uploadDate")
    public String uploadDate(HttpServletRequest request, 
			  HttpServletResponse response) throws Exception {
    	
    	UploadUtil uploadUtil = new UploadUtil(ConstantUtils.LEAVE_FILE_PATH, 
				  ConstantUtils.FILE_TEMP, ConstantUtils.FILE_TYPES);
    	uploadUtil.upload(request);
    	String filePath = uploadUtil.getFilePath();
    	
    	boolean resultFlag = uploadService.uploadUserDate(filePath);
    	
		JSONObject result = new JSONObject();
		if (resultFlag) {
			result.put("success", true);
		} else {
			result.put("success", false);
		}

		ResponseUtil.write(response, result);
		return null;
    }
}
