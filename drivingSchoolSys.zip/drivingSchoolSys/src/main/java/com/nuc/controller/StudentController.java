package com.nuc.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nuc.model.AppointmentInfo;
import com.nuc.model.MemberShipEntity;
import com.nuc.model.UserEntity;
import com.nuc.service.AppointmentService;
import com.nuc.service.MemberShipService;
import com.nuc.service.UserService;
import com.nuc.util.UUIDUtil;

@Controller
@RequestMapping("student")
public class StudentController {
	
    @Autowired
    private MemberShipService memberShipService;
    
    @Autowired
	private AppointmentService appointmentService;
    
	@Autowired
	private UserService userService;

	@RequestMapping("login")
	public void login(HttpServletRequest requset, HttpServletResponse response) throws IOException {
		String userName = requset.getParameter("username");
        String password=requset.getParameter("password");
        String roleId=requset.getParameter("roleId");
        
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("username",userName);
        map.put("password",password);
        map.put("roleId",roleId);
        
        MemberShipEntity memberShipEntity = memberShipService.login(map);
        if(memberShipEntity == null){
        	response.sendRedirect("/studentLogin");
        }else{
            requset.getSession().setAttribute("student", memberShipEntity);
            response.sendRedirect("/studentIndex");
        }
	}
	
	@RequestMapping("logout")
	public void logout(HttpServletRequest requset, HttpServletResponse response) throws IOException {
		requset.getSession().removeAttribute("student");
		response.sendRedirect("/studentLogin");
	}
	
	@RequestMapping("selectAppointment")
	public void selectAppointment(String id, HttpServletRequest requset, HttpServletResponse response) throws IOException {
		MemberShipEntity memberShipEntity = (MemberShipEntity) requset.getSession().getAttribute("student");
		Integer userId = memberShipEntity.getUserEntity().getUserId();
		String uuid = UUIDUtil.getUUID();
		
		Map<String,Object> map = new HashMap<String, Object>();
        map.put("uuid",uuid);
        map.put("appointmentId",id);
        map.put("userId",userId);
		appointmentService.addUserAppointment(map);
		response.sendRedirect("/student/myRecord");
	}
	
	@RequestMapping("delSelectAppointment")
	public void delSelectAppointment(String id, HttpServletRequest requset, HttpServletResponse response) throws IOException {
		MemberShipEntity memberShipEntity = (MemberShipEntity) requset.getSession().getAttribute("student");
		Integer userId = memberShipEntity.getUserEntity().getUserId();
		
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("appointmentId",id);
		map.put("userId",userId);
		appointmentService.delUserAppointment(map);
		response.sendRedirect("/student/myRecord");
	}
	
	@RequestMapping("stuLookAppointment")
	public ModelAndView stuLookAppointment(HttpServletRequest requset, HttpServletResponse response) throws IOException {
		ModelAndView modelAndView = new ModelAndView("student/login/login");
		MemberShipEntity memberShipEntity = (MemberShipEntity) requset.getSession().getAttribute("student");
		if(memberShipEntity == null) {
			return modelAndView;
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("status", "1");

		List<AppointmentInfo> appointmentList = appointmentService.getAppointmentList(map);
		for (AppointmentInfo entity : appointmentList) {
			if ("0".equals(entity.getStatus())) {
				entity.setStatus("未发布");
			} else {
				entity.setStatus("已发布");
			}

			UserEntity userEntity = userService.findById(entity.getUserId().toString());
			entity.setUserName(userEntity.getRealName());

			List<String> userIdList = appointmentService.getAppointmentNum(entity.getAppointmentId());
			entity.setAppointmentNum(userIdList.size());
		}
		modelAndView = new ModelAndView("student/stuLookAppointment");
		modelAndView.addObject("appointmentList", appointmentList);
		
		return modelAndView;
	}
	
	@RequestMapping("myRecord")
	public ModelAndView myRecord(HttpServletRequest requset, HttpServletResponse response) throws IOException {
		ModelAndView modelAndView = new ModelAndView("student/login/login");
		MemberShipEntity memberShipEntity = (MemberShipEntity) requset.getSession().getAttribute("student");
		if(memberShipEntity == null) {
			return modelAndView;
		}
		
		int userId = memberShipEntity.getUserEntity().getUserId();
		List<String> appointmentIdList = appointmentService.getAppointmentNumByUserId(userId);
		List<AppointmentInfo> appointmentList = new ArrayList<>();
		for (String appointmentId : appointmentIdList) {
			appointmentList.add(appointmentService.selectByPrimaryKey(appointmentId));
		}

		for (AppointmentInfo entity : appointmentList) {
			if ("0".equals(entity.getStatus())) {
				entity.setStatus("未发布");
			} else {
				entity.setStatus("已发布");
			}
			
			UserEntity userEntity = userService.findById(entity.getUserId().toString());
			entity.setUserName(userEntity.getRealName());
			
			List<String> userIdList = appointmentService.getAppointmentNum(entity.getAppointmentId());
			entity.setAppointmentNum(userIdList.size());
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	        Date ten = null;
	        Date now = null;
	        try {
	            ten = format.parse(entity.getAppointmentDate());
	            now = new Date();
	            if(ten.getTime() < now.getTime()) {
	            	entity.setIsSelect("false");
	            }
	        } catch (ParseException e) {
	            e.printStackTrace();
	        }
		}
		modelAndView = new ModelAndView("student/myRecord");
		modelAndView.addObject("appointmentList", appointmentList);
		
		return modelAndView;
	}
	
	@RequestMapping("stuRecordAppointment")
	public ModelAndView stuRecordAppointment(HttpServletRequest requset, HttpServletResponse response) throws IOException {
		ModelAndView modelAndView = new ModelAndView("student/login/login");
		MemberShipEntity memberShipEntity = (MemberShipEntity) requset.getSession().getAttribute("student");
		if(memberShipEntity == null) {
			return modelAndView;
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("status", "1");
		map.put("appointmentCollage", memberShipEntity.getUserEntity().getCollage());
		map.put("appointmentClassId", memberShipEntity.getUserEntity().getClassId());
		
		List<AppointmentInfo> appointmentList = appointmentService.getAppointmentList(map);
		List<String> appointmentIdList = appointmentService.getAppointmentNumByUserId(memberShipEntity.getUserEntity().getUserId());
		for (AppointmentInfo entity : appointmentList) {
			if ("0".equals(entity.getStatus())) {
				entity.setStatus("未发布");
			} else {
				entity.setStatus("已发布");
			}
			
			UserEntity userEntity = userService.findById(entity.getUserId().toString());
			entity.setUserName(userEntity.getRealName());
			
			List<String> userIdList = appointmentService.getAppointmentNum(entity.getAppointmentId());
			entity.setAppointmentNum(userIdList.size());
			
			entity.setIsSelect("true");
			if(entity.getAppointmentTotal() <= entity.getAppointmentNum()) {
				entity.setIsSelect("false");
			}
			
			if(appointmentIdList.contains(entity.getAppointmentId())) {
				entity.setIsSelect("false");
			}

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	        Date ten = null;
	        Date now = null;
	        try {
	            ten = format.parse(entity.getAppointmentDate());
	            now = new Date();
	            if(ten.getTime() < now.getTime()) {
	            	entity.setIsSelect("false");
	            }
	        } catch (ParseException e) {
	            e.printStackTrace();
	        }
		}
		modelAndView = new ModelAndView("student/stuRecordAppointment");
		modelAndView.addObject("appointmentList", appointmentList);
		
		return modelAndView;
	}

}
