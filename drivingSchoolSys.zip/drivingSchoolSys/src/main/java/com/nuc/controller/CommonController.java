package com.nuc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CommonController {

	// 系统登录界面
	@RequestMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	// 系统首页
	@RequestMapping("/main")
	public String mainPage() {
		return "main";
	}
	
	// 学员登录界面
	@RequestMapping("/studentLogin")
	public String studentLogin() {
		return "student/login/login";
	}
	
	// 学员登录界面
	@RequestMapping("/studentIndex")
	public String studentIndex() {
		return "student/index";
	}
	
}
