package com.nuc.controller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nuc.util.ConstantUtils;
import com.nuc.util.FileDownloadUtil;

/**
 * @className DownloadController.java
 * @author HowardAllen
 * @date 2019年5月10日 下午2:12:45
 * @Description 下载Controller
 */

@Controller
@RequestMapping("download")
public class DownloadController {
	
	private final static String USERDATA_FILE_MODEL_PATH = "d:/fileModel/2_学员信息导入模板.xlsx";
	
	/**
	 * 下载文件模板
	 * @param request
	 * @param response
	 */
	@RequestMapping("fileModel")
	public void fileModel(HttpServletRequest request, HttpServletResponse response) {
		String type = request.getParameter("type");
		File file = null;
		
		switch (type) {
		case ConstantUtils.TWO_STR:
			file = new File(USERDATA_FILE_MODEL_PATH);
			break;
		}
		
		String filePath = file.getAbsolutePath();
		String returnName = filePath.substring(filePath.lastIndexOf("_") + 1);
		
		FileDownloadUtil fileDownloadUtil = new FileDownloadUtil();
		fileDownloadUtil.prototypeDownload(file, returnName, response, false);
	}
	
}
