package com.nuc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nuc.model.PageBean;
import com.nuc.model.RoleEntity;
import com.nuc.service.RoleService;
import com.nuc.util.ResponseUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
* @author HowardAllen
* @version 2019年4月6日 上午11:58:21
* Disc 角色Controller
*/

@Controller
@RequestMapping("role")
public class RoleController {

	private static final Logger logger = LoggerFactory.getLogger(RoleController.class);
	
	@Autowired
	private RoleService roleSerivce;
	
	/**
	 * 获取登录时选择角色的数据
	 * @param response
	 * @return
	 */
	@RequestMapping("getRoleList")
	public String getRoleList(HttpServletResponse response) {
		
		JSONObject object = new JSONObject();
		object.put("roleId", -1);
        object.put("roleName", "请选择角色..");
        
        JSONArray array = new JSONArray();
        array.add(object);
        
        try {
        	// List<RoleEntity> list = roleSerivce.fingByPage(null);
        	List<RoleEntity> list = new ArrayList<>();
            RoleEntity roleEntity1 = new RoleEntity();
            roleEntity1.setRoleId("1");
            roleEntity1.setRoleName("管理员");
            RoleEntity roleEntity2 = new RoleEntity();
            roleEntity2.setRoleId("8");
            roleEntity2.setRoleName("教练");
            list.add(roleEntity1);
            list.add(roleEntity2);
            JSONArray jsonArray = JSONArray.fromObject(list);
            array.addAll(jsonArray);

            ResponseUtil.write(response, array);
        } catch (Exception e) {
            logger.error("对不起 发生未知错误" + e.getMessage());
        }
        return null;
	}
	
	 /**
     * 分页条件查询角色
     *
     * @param page
     * @param rows
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/list")
    public String list(
    		@RequestParam(value = "page", required = false) String page, 
    		@RequestParam(value = "rows", required = false) String rows, 
    		HttpServletResponse response) throws Exception {
    	
        try {
        	
            PageBean pageBean = new PageBean(Integer.parseInt(page), Integer.parseInt(rows));
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("start", pageBean.getStart());
            map.put("size", pageBean.getPageSize());
            
            List<RoleEntity> result = roleSerivce.fingByPage(map);
            Long total = roleSerivce.getTotal(map);
            
            JSONObject object = new JSONObject();
            JSONArray jsonArray = JSONArray.fromObject(result);
            object.put("total", total);
            object.put("rows", jsonArray);
            
            ResponseUtil.write(response, object);
            
        } catch (Exception e) {
            logger.error("分页查询失败" + e.getMessage());
        }

        return null;
    }
    
    /**
     * 添加或者修角色
     *
     * @param group
     * @param response
     * @param flag     1 添加  2修改
     * @return
     * @throws Exception
     */
    @RequestMapping("/save")
    public String save(RoleEntity role, HttpServletResponse response, Integer flag) throws Exception {

        int resultTotal = 0;//记载操作数

        try {
            if (flag == 1) {
                resultTotal = roleSerivce.addRole(role);
            } else {
                resultTotal = roleSerivce.update(role);
            }

            JSONObject object = new JSONObject();
            if (resultTotal > 0) {
                object.put("success", true);
            } else {
                object.put("success", false);
            }
            ResponseUtil.write(response, object);
            
        } catch (Exception e) {
            logger.error("添加或修改失败" + e.getMessage());
        }

        return null;
    }


    /**
     * 删除角色
     *
     * @param ids
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/delete")
    public String delete(
    		@RequestParam(value = "ids") String ids, 
    		HttpServletResponse response) throws Exception {
    	
        String[] idsStr = ids.split(",");
        for (int i = 0; i < idsStr.length; i++) {
        	roleSerivce.delete(idsStr[i]);
        }
        
        JSONObject result = new JSONObject();
        result.put("success", true);
        ResponseUtil.write(response, result);
        
        return null;
    }
    
    /**
     * desc 判断是否存在指定角色名
     *
     * @param groupName
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/existRoleName")
    public String existUserName(String roleName, HttpServletResponse response) throws Exception {
    	
        JSONObject result = new JSONObject();
        
        if (roleSerivce.findByRoleName(roleName) == null) {
            result.put("exist", false);
        } else {
            result.put("exist", true);
        }
        
        ResponseUtil.write(response, result);
        return null;
    }
    
    /**
     * desc 查询所有角色
     *
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping("/listAllRoles")
    public String listAllGroups(HttpServletResponse response) throws Exception {
        List<RoleEntity> groupList = roleSerivce.fingByPage(null);
        JSONObject result = new JSONObject();
        JSONArray jsonArray = JSONArray.fromObject(groupList);
        result.put("groupList", jsonArray);
        ResponseUtil.write(response, result);
        return null;
    }
}
