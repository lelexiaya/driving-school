package com.nuc.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nuc.model.MemberShipEntity;
import com.nuc.model.RoleEntity;
import com.nuc.model.UserEntity;
import com.nuc.service.MemberShipService;
import com.nuc.util.ResponseUtil;
import com.nuc.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * Created by tb on 2016/10/30.
 */
@Controller
@RequestMapping("/memberShip")
public class MemberShipController {

    private static final Logger logger = LoggerFactory.getLogger(MemberShipController.class);
    
    @Resource
    private MemberShipService memberShipService;


    /**
     * desc 更新用户权限（先删除，再批量添加）
     * @param userId
     * @param
     * @param response
     * @return
     * @throws Exception
     */

    @RequestMapping("/update")
    public String updateMemberShip(String userId, String groupIds, HttpServletResponse response){
        try{
            memberShipService.deleteAllRoleByUserId(userId);
            if(StringUtil.isNotEmpty(groupIds)){
                String idsArr[] = groupIds.split(",");
                for(String groupId:idsArr){
                    UserEntity user = new UserEntity();
                    user.setUserId(Integer.valueOf(userId));
                    RoleEntity group = new RoleEntity();
                    group.setRoleId(groupId);
                    MemberShipEntity memberShip = new MemberShipEntity();
                    memberShip.setUserEntity(user);
                    memberShip.setRoleEntity(group);
                    memberShipService.add(memberShip);
                }
            }
            JSONObject result=new JSONObject();
            result.put("success", true);
            ResponseUtil.write(response, result);

        }catch (Exception e){
            logger.error("修改失败"+e.getMessage());
        }
        return null;
    }

}
