package com.nuc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nuc.model.AppointmentInfo;
import com.nuc.model.PageBean;
import com.nuc.model.UserEntity;
import com.nuc.service.AppointmentService;
import com.nuc.service.UserService;
import com.nuc.util.ConstantUtils;
import com.nuc.util.ResponseUtil;
import com.nuc.util.TimeUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("appointment")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@Autowired
	private UserService userService;

	@RequestMapping("/list")
	public String list(@RequestParam(value = "page", required = false) String page,
			@RequestParam(value = "rows", required = false) String rows, AppointmentInfo appointment,
			HttpServletResponse response) throws Exception {

		PageBean pageBean = new PageBean(Integer.parseInt(page), Integer.parseInt(rows));

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("start", pageBean.getStart());
		map.put("size", pageBean.getPageSize());
		map.put("userId", appointment.getUserId());

		List<AppointmentInfo> appointmentList = appointmentService.getAppointmentList(map);
		for (AppointmentInfo entity : appointmentList) {
			if ("0".equals(entity.getStatus())) {
				entity.setStatus("未发布");
			} else {
				entity.setStatus("已发布");
			}

			UserEntity userEntity = userService.findById(entity.getUserId().toString());
			entity.setUserName(userEntity.getRealName());

			List<String> userIdList = appointmentService.getAppointmentNum(entity.getAppointmentId());
			entity.setAppointmentNum(userIdList.size());
		}
		Long total = appointmentService.getTotal(map);

		JSONObject result = new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(appointmentList);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(response, result);

		return null;
	}

	@RequestMapping("/userList")
	public String userList(String appointmentId, HttpServletResponse response) throws Exception {
		List<String> userIdList = appointmentService.getAppointmentNum(appointmentId);

		List<UserEntity> userList = new ArrayList<>();
		for (String string : userIdList) {
			UserEntity user = userService.findById(string);
			userList.add(user);
		}

		JSONObject result = new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(userList);
		result.put("rows", jsonArray);
		ResponseUtil.write(response, result);
		return null;
	}
	
	@RequestMapping("/updateAppointmentStatus")
	public String updateAppointmentStatus(String appointmentId, HttpServletResponse response) throws Exception {
		AppointmentInfo appointment = new AppointmentInfo();
		
		appointment.setAppointmentId(appointmentId);
		appointment.setStatus("1");
		appointmentService.updateAppointment(appointment);

		JSONObject result = new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject("[]");
		result.put("result", jsonArray);
		ResponseUtil.write(response, result);
		return null;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(AppointmentInfo appointment, HttpServletRequest request, HttpServletResponse response, Integer flag)
			throws Exception {

		int resultTotal = 0; // 操作的记录条数

		appointment.setAppointmentDate(appointment.getAppointmentDate().split(" ")[0]);
		if (flag == ConstantUtils.ONE_NUMBER) {
			Integer userId = appointment.getUserId();
			UserEntity user = userService.findById(userId.toString());
			
			appointment.setAppointmentId(TimeUtil.getUserDate("yyyyMMddhhmmssSSS"));
			appointment.setAppointmentClassId(user.getClassId());
			appointment.setAppointmentCollage(user.getCollage());
			appointment.setStatus("0");
			
			resultTotal = appointmentService.addAppointment(appointment);
		} else {
			resultTotal = appointmentService.updateAppointment(appointment);
		}

		JSONObject result = new JSONObject();
		if (resultTotal > 0) {
			result.put("success", true);
		} else {
			result.put("success", false);
		}

		ResponseUtil.write(response, result);
		return null;
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam(value = "ids") String ids, HttpServletResponse response) throws Exception {

		String[] idsStr = ids.split(",");
		for (int i = 0; i < idsStr.length; i++) {
			appointmentService.delete(idsStr[i]);
		}

		JSONObject result = new JSONObject();
		result.put("success", true);
		ResponseUtil.write(response, result);

		return null;
	}
	
}
