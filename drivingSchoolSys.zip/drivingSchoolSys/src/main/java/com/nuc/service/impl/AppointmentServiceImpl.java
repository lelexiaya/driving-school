package com.nuc.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nuc.dao.AppointmentInfoDao;
import com.nuc.model.AppointmentInfo;
import com.nuc.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService{

	@Autowired
	private AppointmentInfoDao  appointmentInfoDao;

	@Override
	public List<AppointmentInfo> getAppointmentList(Map<String, Object> map) {
		return appointmentInfoDao.selectAppointment(map);
	}

	@Override
	public Long getTotal(Map<String, Object> map) {
		return appointmentInfoDao.getTotal(map);
	}

	@Override
	public int addAppointment(AppointmentInfo appointment) {
		return appointmentInfoDao.insert(appointment);
	}

	@Override
	public int updateAppointment(AppointmentInfo appointment) {
		return appointmentInfoDao.updateByPrimaryKeySelective(appointment);
	}

	@Override
	public int delete(String appointmentId) {
		return appointmentInfoDao.deleteByPrimaryKey(appointmentId);
	}

	@Override
	public List<String> getAppointmentNum(String appointmentId) {
		return appointmentInfoDao.getAppointmentNum(appointmentId);
	}

	@Override
	public int addUserAppointment(Map<String, Object> map) {
		return appointmentInfoDao.addUserAppointment(map);
	}

	@Override
	public int delUserAppointment(Map<String, Object> map) {
		return appointmentInfoDao.delUserAppointment(map);
	}

	@Override
	public List<String> getAppointmentNumByUserId(Integer userId) {
		return appointmentInfoDao.getAppointmentNumByUserId(userId);
	}

	@Override
	public AppointmentInfo selectByPrimaryKey(String appointmentId) {
		return appointmentInfoDao.selectByPrimaryKey(appointmentId);
	}
	
	
	
}
