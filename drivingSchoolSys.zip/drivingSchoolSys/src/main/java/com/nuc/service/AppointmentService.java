package com.nuc.service;

import java.util.List;
import java.util.Map;

import com.nuc.model.AppointmentInfo;

public interface AppointmentService {

	List<AppointmentInfo> getAppointmentList(Map<String,Object> map);
	
	Long getTotal(Map<String, Object> map);
	
	int addAppointment(AppointmentInfo appointment);
	
	int addUserAppointment(Map<String, Object> map);
	
	int delUserAppointment(Map<String, Object> map);
	
	int updateAppointment(AppointmentInfo appointment);
	
	int delete(String appointmentId);
	
	List<String> getAppointmentNum(String appointmentId);
	
	List<String> getAppointmentNumByUserId(Integer userId);
	
	AppointmentInfo selectByPrimaryKey(String appointmentId);
}
