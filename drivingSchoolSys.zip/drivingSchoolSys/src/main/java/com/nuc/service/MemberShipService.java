package com.nuc.service;

import java.util.Map;

import com.nuc.model.MemberShipEntity;

/**
 * Created by tb on 2016/10/30.
 */
public  interface MemberShipService {

    /**
     * 用户登录
     * @param map
     *
     * @return
     */
	MemberShipEntity login(Map<String,Object> map);

    /**
     * desc 删除指定用户所有角色
     * @param userId
     * @return
     */
    int  deleteAllRoleByUserId(String userId);

    /**
     * desc 添加用户权限
     * @param memberShip
     * @return
     */
    int add(MemberShipEntity memberShip);
}
