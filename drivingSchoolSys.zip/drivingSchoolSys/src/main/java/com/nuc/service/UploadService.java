package com.nuc.service;

/**
 * @className UploadService.java
 * @author HowardAllen
 * @date 2019年5月20日 下午9:47:40
 * @Description 描述信息
 */

public interface UploadService {

	public boolean uploadUserDate(String filePath);
	
}
