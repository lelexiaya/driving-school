package com.nuc.service;

import java.util.List;
import java.util.Map;

import com.nuc.model.RoleEntity;

/**
* @author HowardAllen
* @version 2019年4月6日 下午12:00:59
* Disc 角色业务层
*/

public interface RoleService {

	/**
	 * 查询角色信息
	 * @param map 保存分页信息
	 * @return
	 */
	public List<RoleEntity> fingByPage(Map<String, Object> map);
	
	/**
	 * 查询角色记录数
	 * @param map
	 * @return
	 */
	public Long getTotal(Map<String, Object> map);
	
	/**
	 * 通过角色ID查询角色信息
	 * @param roleId
	 * @return
	 */
	RoleEntity findById(String roleId);
	
	/**
	 * desc 通过用户ID查询角色信息
	 * @param userId
	 * @return
	 */
	List<RoleEntity> findByUserId(Integer userId);
	
	/**
	 * 根据角色名查询角色信息
	 * @param roleName
	 * @return
	 */
	RoleEntity findByRoleName(String roleName);
	
	/**
	 * 添加角色信息
	 * @param entity
	 * @return
	 */
	int addRole(RoleEntity entity);
	
	/**
	 * 修改角色信息
	 * @param entity
	 * @return
	 */
	int update(RoleEntity entity);
	
	
	/**
	 * 删除角色
	 * @param id
	 * @return
	 */
	int delete(String id);
}
