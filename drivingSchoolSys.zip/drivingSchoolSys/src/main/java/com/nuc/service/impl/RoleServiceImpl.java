package com.nuc.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nuc.dao.RoleDao;
import com.nuc.model.RoleEntity;
import com.nuc.service.RoleService;

/**
* @author HowardAllen
* @version 2019年4月6日 下午12:02:27
* Disc 角色业务实现类
*/

@Service
public class RoleServiceImpl implements RoleService{
	
	@Autowired
	private RoleDao roleDao;

	@Override
	public List<RoleEntity> fingByPage(Map<String, Object> map) {
		return roleDao.findByPage(map);
	}

	@Override
	public Long getTotal(Map<String, Object> map) {
		return roleDao.getTotal(map);
	}

	@Override
	public int addRole(RoleEntity entity) {
		return roleDao.addRole(entity);
	}

	@Override
	public int update(RoleEntity entity) {
		return roleDao.updateRole(entity);
	}

	@Override
	public int delete(String id) {
		return roleDao.deleteRole(id);
	}

	@Override
	public RoleEntity findById(String roleId) {
		return roleDao.findById(roleId);
	}

	@Override
	public RoleEntity findByRoleName(String roleName) {
		return roleDao.findByRoleName(roleName);
	}

	@Override
	public List<RoleEntity> findByUserId(Integer userId) {
		return roleDao.findByUserId(userId);
	}

}
