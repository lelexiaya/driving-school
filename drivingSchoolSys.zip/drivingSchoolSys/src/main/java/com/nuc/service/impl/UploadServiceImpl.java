package com.nuc.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nuc.dao.UserDao;
import com.nuc.model.UserEntity;
import com.nuc.service.UploadService;
import com.nuc.util.CSVUtil;
import com.nuc.util.ConstantUtils;
import com.nuc.util.ParseExcelUtil;

/**
 * @className UploadServiceImpl.java
 * @author HowardAllen
 * @date 2019年5月20日 下午9:48:38
 * @Description 描述信息
 */

@Service
public class UploadServiceImpl implements UploadService {
	
	private static final String USERDATA_FILENAME = "_userdata.csv";
	
	private static final String ROLEDATA_FILENAME = "_roledata.csv";
	
	@Autowired
	private UserDao userDao;

	@Override
	public boolean uploadUserDate(String filePath) {
		
		List<String> dataList = new ArrayList<>();
		List<String> dataRoleList = new ArrayList<>();
		
		List<UserEntity> userList = ParseExcelUtil.paresExcel(filePath);
		for (UserEntity userEntity : userList) {
			String data = userEntity.getUsername() + "," +
					userEntity.getUsername() + "," +
					userEntity.getPassword() + "," +
					userEntity.getRealName() + "," +
					userEntity.getSex() + "," +
					userEntity.getCardId() + "," +
					userEntity.getCollage() + "," +
					userEntity.getMajor() + "," +
					userEntity.getClassId() + "," +
					userEntity.getAddress() + "," +
					userEntity.getEmail();
			dataList.add(data);
			
			String dataRole = userEntity.getUsername() + "," + 2;
			dataRoleList.add(dataRole);
		}
		
		String userFilePath = uploadFileTypeToCSV(filePath, ConstantUtils.ONE_NUMBER);
		CSVUtil.exportCsv(new File(userFilePath), dataList);
		userDao.uploadDate(userFilePath);
		
		String roleFilePath = uploadFileTypeToCSV(filePath, ConstantUtils.TWO_NUMBER);
		CSVUtil.exportCsv(new File(roleFilePath), dataRoleList);
		userDao.uploadDateRole(roleFilePath);
		
		return true;
	}

	private String uploadFileTypeToCSV(String filePath, int type) {
		String newFile = "";
		if(ConstantUtils.ONE_NUMBER == type) {
			newFile = filePath.substring(0, filePath.lastIndexOf("_")) + USERDATA_FILENAME;
		}
		else if(ConstantUtils.TWO_NUMBER == type) {
			newFile = filePath.substring(0, filePath.lastIndexOf("_")) + ROLEDATA_FILENAME;
		}
		return newFile;
	}
}
