package com.nuc.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nuc.dao.UserDao;
import com.nuc.model.UserEntity;
import com.nuc.service.UserService;

@Service("UserService")
public class UserServiceImpl  implements UserService{

    @Autowired
    private UserDao userDao;
    
    public UserEntity findById(String id) {
        return userDao.findById(id);
    }

    public List<UserEntity> find(Map<String, Object> map) {
        return userDao.find(map);
    }

    public Long getTotal(Map<String, Object> map) {
        return userDao.getTotal(map);
    }

    public int update(UserEntity user) {
        return userDao.update(user);
    }

    public int add(UserEntity user) {
        return userDao.add(user);
    }

    public int delete(String userId) {
    	return userDao.delete(userId);
    }

	@Override
	public UserEntity findByUsername(String username) {
		return userDao.findByUsername(username);
	}

	@Override
	public List<UserEntity> getCollageList(Map<String, Object> map) {
		return userDao.getCollageList(map);
	}

	@Override
	public List<UserEntity> getClassIdList(Map<String, Object> map) {
		return userDao.getClassIdList(map);
	}

	@Override
	public List<UserEntity> getUserInfoByRoleName(String roleName) {
		Map<String, Object> map = new HashMap<>();
		map.put("roleName", roleName);
		return userDao.getUserInfoByRoleName(map);
	}
}
