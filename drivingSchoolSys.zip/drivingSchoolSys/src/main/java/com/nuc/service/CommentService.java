package com.nuc.service;

import java.util.List;

import com.nuc.model.CommentEntity;

/**
* @author HowardAllen
* @version 2019年4月22日 上午9:46:17
* Disc 这个类的说明
*/

public interface CommentService {

	/**
	 * desc 通过任务ID来查询流程实例的所有批注
	 * @param taskId
	 * @return
	 */
	public List<CommentEntity> getCommentList(String taskId);

	/**
	 * desc 通过流程实例ID来查询流程实例的所有批注
	 * @param processInstanceId
	 * @return
	 */
	public List<CommentEntity> getCommentListByProcessInstaceId(String processInstanceId);
}
