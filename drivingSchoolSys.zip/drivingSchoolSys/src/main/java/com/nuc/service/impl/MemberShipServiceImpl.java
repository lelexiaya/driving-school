package com.nuc.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nuc.dao.MemberShipDao;
import com.nuc.model.MemberShipEntity;
import com.nuc.service.MemberShipService;

/**
 * Created by tb on 2016/10/30.
 */
@Service("MemberShipService")
public class MemberShipServiceImpl implements MemberShipService {

    @Autowired
    private MemberShipDao memberShipDao;

    public MemberShipEntity login(Map<String, Object> map) {
    	return memberShipDao.login(map);
    }

    public int deleteAllRoleByUserId(String userId) {
        return memberShipDao.deletAllRoleById(userId);
    }

    public int add(MemberShipEntity memberShip) {
        return memberShipDao.add(memberShip);
    }
}
