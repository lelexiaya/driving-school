package com.nuc.service;

import java.util.List;
import java.util.Map;

import com.nuc.model.UserEntity;

 public interface UserService {

    /**
     * 通过id查询用户实体
     * @param id
     * @return
     */
     UserEntity findById(String id);
     
     /**
      * 通过username查询用户实体
      * @param username
      * @return
      */
     UserEntity findByUsername(String username);

    /**
     * 根据条件查询用户集合
     * @param map
     * @return
     */
     List<UserEntity> find(Map<String,Object> map);

    /**
     * 获取总记录数
     * @param map
     * @return
     */
     Long getTotal(Map<String,Object> map);

    /**
     * 修改用户
     * @param user
     * @return
     */
     int update(UserEntity user);

    /**
     * 添加用户
     * @param user
     * @return
     */
     int add(UserEntity user);

    /**
     * 删除用户
     * @param id
     * @return
     */
     int delete(String id);
     
     /**
      * 获取专业列表
      * @param map
      * @return
      */
     List<UserEntity> getCollageList(Map<String, Object> map);
     
     /**
      * 获取班级列表
      * @param map
      * @return
      */
     List<UserEntity> getClassIdList(Map<String, Object> map);
     
     /**
      * 获取教师信息列表
      * @param roleName 角色名称
      * @return
      */
     List<UserEntity> getUserInfoByRoleName(String roleName);
}
