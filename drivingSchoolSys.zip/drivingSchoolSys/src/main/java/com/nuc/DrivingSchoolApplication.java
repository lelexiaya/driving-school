package com.nuc;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = { "com.nuc.dao" })
public class DrivingSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrivingSchoolApplication.class, args);
	}

}
