package com.nuc.config;

import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

/**
* @author HowardAllen
* @version 2019年4月6日 上午12:25:27
* Disc 配置拦截器
*/

public class WebAppConfig extends WebMvcConfigurationSupport {

	/**
	 * 配置拦截器，阻止普通用户和游客进入管理员界面，阻止游客进行个人信息有关操作
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new BasicInterceptor())
			.addPathPatterns(
					"/admin/**",
					"/news/admin/**",
					"/team/admin/**",
					"/user/info");
	}
	
	/**
	 * 配置默认欢迎URL
	 */
	/*
	 * @Override public void addViewControllers(ViewControllerRegistry registry) {
	 * 
	 * registry.addViewController("/").setViewName("login");
	 * 
	 * registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
	 * 
	 * super.addViewControllers(registry);
	 * 
	 * }
	 */
	
}
