package com.nuc.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.nuc.model.UserEntity;

/**
* @author HowardAllen
* @version 2019年4月6日 上午12:25:27
* Disc 对未登录用户拦截
*/
public class BasicInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger(BasicInterceptor.class);
	 
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
 
		// 对未登录用户进行拦截
		UserEntity user = (UserEntity)request.getSession().getAttribute("user");
		if(user == null) {
			response.sendRedirect(request.getContextPath()+"/");
		    logger.info("用户未登录，不允许进行请求:"+request.getRequestURL());
			return false;
		}
		
		return true;
	}
	
}
