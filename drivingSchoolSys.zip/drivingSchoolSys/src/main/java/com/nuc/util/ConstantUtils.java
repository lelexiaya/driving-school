package com.nuc.util;

/**
* @author HowardAllen
* @version 2019年4月16日 上午11:56:32
* Disc 常量接口类
*/

public interface ConstantUtils {

	/**
	 * 请假流程部署图ID
	 */
	public static final String LEAVE_MANAGE = "leave_manage";
	
	/**
	 * 请假申请任务定义ID
	 */
	public static final String LEAVE_APPLY = "leave_apply";
	
	/**
	 * 教师审批任务定义ID
	 */
	public static final String TEACHER_AUDIT = "teacher_audit";
	
	/**
	 * 院长审批任务定义ID
	 */
	public static final String DEAN_AUDIT = "dean_audit";
	
	/**
	 * 字符串学生
	 */
	public static final String STUDENT = "student";
	
	/**
	 * 字符串教师
	 */
	public static final String TEACHER = "teacher";
	
	/**
	 * 字符串院长
	 */
	public static final String DEAN = "dean";
	
	/**
	 * 字符串 男
	 */
	public static final String MAN_STR = "男";
	
	/**
	 * 字符串 女
	 */
	public static final String WOMAN_STR = "女";
	
	/**
	 * 字符串 1
	 */
	public static final String ONE_STR = "1";
	
	
	/**
	 * 字符串 1
	 */
	public static final String TWO_STR = "2";
	
	/**
	 * 字符串 0
	 */
	public static final String ZERO_STR = "0";
	
	/**
	 * 数字 1
	 */
	public static final int ONE_NUMBER = 1;
	
	/**
	 * 数字 2
	 */
	public static final int TWO_NUMBER = 2;
	
	/**
	 * 中文字符：学生
	 */
	public static final String STR_CH_STUDENT = "学生";
	
	/**
	 * 中文字符：教师
	 */
	public static final String STR_CH_TEACHER = "教师";
	
	/**
	 * 中文字符：院长
	 */
	public static final String STR_CH_DEAN = "院长";
	
	/**
	 * 中文字符：管理员
	 */
	public static final String STR_CH_ADMIN = "管理员";
	
	/**
	 * 中文字符："学生处"
	 */
	public static final String STR_CH_STUDENT_OFFICE = "学生处";
	
	/**
	 * 活动流程审批流程部署图ID
	 */
	public static final String ACTIVITY_PROCESS = "activity_process";
	
	/**
	 * 期末答疑预约流程部署图ID
	 */
	public static final String APPOINTMENT_PROCESS = "appointment_process";
	
	/**
	 * 保存请假证明资料路径
	 */
	public static final String LEAVE_FILE_PATH = "D:\\campus\\leave";
	
	/**
	 * 保存活动方案路径
	 */
	public static final String ACTIVITY_FILE_PATH = "D:\\campus\\acitvity";
	
	/**
	 * 保存文件的临时路径
	 */
	public static final String FILE_TEMP = "D:\\temp";
	
	/**
	 * 允许上传的文件类型
	 */
	public static final String[] FILE_TYPES = {"txt", "docx", "xls", "xlsx", "doc"};
}
