package com.nuc.util;

import java.io.FileInputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.nuc.model.UserEntity;
import com.nuc.util.dataCenter.IdCardGenerator;

/**
* @author HowardAllen
* @version 2019年4月6日 上午12:48:14
* Disc 解析Excel文件工具类
*/

public class ParseExcelUtil {
	
	private static IdCardGenerator idCardGenerator = new IdCardGenerator();

	/**
	 * 解析学生Excel文件
	 * @param filePath 文件地址
	 * @return
	 */
	public static List<UserEntity> paresExcel(String filePath){
		List<UserEntity> userList = new ArrayList<>(16);
		Workbook workbook;
		
		try {
			// 区分.xlsx和.xls来使用不同的解析器
            if (filePath.indexOf(".xlsx") > -1) {
                workbook = new XSSFWorkbook(new FileInputStream(filePath));
            } else {
                workbook = new HSSFWorkbook(new FileInputStream(filePath));
            }

            Sheet sheet = workbook.getSheetAt(0);	// 创建对工作表的引用
            int rows = sheet.getPhysicalNumberOfRows();	// 获取表格的
            int columns = 0;
            // 循环遍历表格的行
            for (int r = 0; r < rows; r++) {
                if (r == 0) {
                    // 在第一行标题行计算出列宽度,因为数据行中可能会有空值
                    columns = sheet.getRow(r).getLastCellNum();
                    continue;
                }

                Row row = sheet.getRow(r); // 获取单元格中指定的行对象
                if (row != null) {
                	UserEntity userEntity = new UserEntity();
                    for (short c = 0; c < columns; c++) { // 循环遍历行中的单元格
                        Cell cell = row.getCell((short) c);
                        if (cell != null) {
                        	saveInfoToEntity(c, cell, userEntity);
                        }
                    }
                    userList.add(userEntity);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

		return userList;
	}
	
	/**
	 * 解析cell中的数据
	 * @param cell
	 * @return
	 */
	private static String getCellValue(Cell cell) {
        DecimalFormat df = new DecimalFormat("#");
        if (cell == null)
            return "";
        switch (cell.getCellType()) {
        case Cell.CELL_TYPE_NUMERIC:
            if (DateUtil.isCellDateFormatted(cell)) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                return sdf.format(cell.getDateCellValue()).toString();
            }
            return df.format(cell.getNumericCellValue());
        case Cell.CELL_TYPE_STRING:
            return cell.getStringCellValue();
        case Cell.CELL_TYPE_FORMULA:
            return cell.getCellFormula();
        case Cell.CELL_TYPE_BLANK:
            return "";
        case Cell.CELL_TYPE_BOOLEAN:
            return cell.getBooleanCellValue() + "";
        case Cell.CELL_TYPE_ERROR:
            return cell.getErrorCellValue() + "";
        }
        return "";
    }
	
	/**
	 * 将单元格的数据放入实体类中
	 * @param index
	 * @param cell
	 * @return
	 */
	private static void saveInfoToEntity(int index, Cell cell, UserEntity userEntity) {
		
		switch (index) {
			case 0:
				userEntity.setUsername(getCellValue(cell));
				break;
			case 1:
				userEntity.setRealName(getCellValue(cell));
				break;
			case 2:
				if(ConstantUtils.MAN_STR.equals(getCellValue(cell))) {
					userEntity.setSex(ConstantUtils.ONE_STR);
				}
				else if(ConstantUtils.WOMAN_STR.equals(getCellValue(cell))){
					userEntity.setSex(ConstantUtils.ZERO_STR);
				}
				break;
			case 3:
				String cardId = idCardGenerator.generate();
				userEntity.setCardId(cardId);
				userEntity.setPassword(cardId.substring(cardId.length() - 6));
				break;
			case 4:
				userEntity.setCollage(getCellValue(cell));
				break;
			case 5:
				userEntity.setMajor(getCellValue(cell));
				break;
			case 6:
				userEntity.setClassId(getCellValue(cell));
				break;
			case 7:
				userEntity.setAddress(getCellValue(cell));
				break;
			case 8:
				userEntity.setEmail(getCellValue(cell));
				break;
			default:
				break;
		}
		
	}
}
