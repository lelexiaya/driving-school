package com.nuc.util;

import java.util.Random;
import java.util.UUID;

public class UUIDUtil {

	public static String getUUID() {
		String uuid = UUID.randomUUID().toString();
		System.out.println(uuid);
		uuid = uuid.replace("-", "");
		return uuid;
	}
	
	/**
	 * java生成随机数字10位数
	 *
	 * @param length[生成随机数的长度]
	 * @return
	 */
	public static String getRandomNickname(int length) {
		String val = "";
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			val += String.valueOf(random.nextInt(10));
		}
		return val;
	}
}
