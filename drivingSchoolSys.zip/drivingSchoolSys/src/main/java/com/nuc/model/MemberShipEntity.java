package com.nuc.model;

/**
* @author HowardAllen
* @version 2019年4月6日 下午3:50:23
* Disc 用户资格实体类
*/

public class MemberShipEntity {

	private UserEntity userEntity;
	
	private RoleEntity roleEntity;

	public UserEntity getUserEntity() {
		return userEntity;
	}

	public void setUserEntity(UserEntity userEntity) {
		this.userEntity = userEntity;
	}

	public RoleEntity getRoleEntity() {
		return roleEntity;
	}

	public void setRoleEntity(RoleEntity roleEntity) {
		this.roleEntity = roleEntity;
	}
	
}
