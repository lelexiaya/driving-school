package com.nuc.model;

/**
* @author HowardAllen
* @version 2019年4月10日 下午7:09:00
* Disc 资源实体类
*/

public class FunctionEntity {

	private Integer funId;
	
	private String funName;
	
	private String funUrl;
	
	private String funDesc;

	public int getFunId() {
		return funId;
	}

	public void setFunId(int funId) {
		this.funId = funId;
	}

	public String getFunName() {
		return funName;
	}

	public void setFunName(String funName) {
		this.funName = funName;
	}

	public String getFunUrl() {
		return funUrl;
	}

	public void setFunUrl(String funUrl) {
		this.funUrl = funUrl;
	}

	public String getFunDesc() {
		return funDesc;
	}

	public void setFunDesc(String funDesc) {
		this.funDesc = funDesc;
	}
	
}
