package com.nuc.model;

public class AppointmentInfo {
    private String appointmentId;

    private String appointmentCollage;

    private String appointmentClassId;

    private Integer userId;

    private Integer appointmentTotal;

    private String appointmentDate;

    private String status;
    
    private String userName;
    
    private Integer appointmentNum;
    
    private String isSelect;
    
    

    public String getIsSelect() {
		return isSelect;
	}

	public void setIsSelect(String isSelect) {
		this.isSelect = isSelect;
	}

	public Integer getAppointmentNum() {
		return appointmentNum;
	}

	public void setAppointmentNum(Integer appointmentNum) {
		this.appointmentNum = appointmentNum;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId == null ? null : appointmentId.trim();
    }

    public String getAppointmentCollage() {
        return appointmentCollage;
    }

    public void setAppointmentCollage(String appointmentCollage) {
        this.appointmentCollage = appointmentCollage == null ? null : appointmentCollage.trim();
    }

    public String getAppointmentClassId() {
        return appointmentClassId;
    }

    public void setAppointmentClassId(String appointmentClassId) {
        this.appointmentClassId = appointmentClassId == null ? null : appointmentClassId.trim();
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getAppointmentTotal() {
        return appointmentTotal;
    }

    public void setAppointmentTotal(Integer appointmentTotal) {
        this.appointmentTotal = appointmentTotal;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate == null ? null : appointmentDate.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }
}