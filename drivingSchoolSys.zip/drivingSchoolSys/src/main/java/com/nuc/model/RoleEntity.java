package com.nuc.model;

/**
* @author HowardAllen
* @version 2019年4月6日 上午11:44:48
* Disc 角色实体类
*/

public class RoleEntity {

	private String roleId;
	
	private String roleName;
	
	private String roleDesc;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	
	
}
