package com.nuc.model;

/**
* @author HowardAllen
* @version 2019年4月6日 上午12:55:57
* Disc 用户实体类
*/

public class UserEntity {

	private int userId;
	
	private String username;
	
	private String password;
	
	private String realName;
	
	private String sex;
	
	private String cardId;
	
	private String collage;
	
	private String major;
	
	private String classId;
	
	private String address;
	
	private String email;
	
	private String groups;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public String getCollage() {
		return collage;
	}

	public void setCollage(String collage) {
		this.collage = collage;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGroups() {
		return groups;
	}

	public void setGroups(String groups) {
		this.groups = groups;
	}

	@Override
	public String toString() {
		return "UserEntity [userId=" + userId + ", username=" + username + ", password=" + password + ", realName="
				+ realName + ", sex=" + sex + ", cardId=" + cardId + ", collage=" + collage + ", major=" + major
				+ ", classId=" + classId + ", address=" + address + ", email=" + email + "]";
	}
	
}
