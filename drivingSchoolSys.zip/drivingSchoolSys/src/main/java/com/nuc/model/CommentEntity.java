package com.nuc.model;

/**
* @author HowardAllen
* @version 2019年4月22日 上午9:39:02
* Disc 批注实体类
*/

public class CommentEntity {

	// 批注信息
	private String message;
	
	// 批注人ID
	private String userId;
	
	// 批注时间
	private String time;
	
	// 批注人详细信息
	private UserEntity userInfo;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public UserEntity getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserEntity userInfo) {
		this.userInfo = userInfo;
	}

	@Override
	public String toString() {
		return "CommentEntity [message=" + message + ", userId=" + userId + ", time=" + time + ", userInfo=" + userInfo
				+ "]";
	}
	
}
