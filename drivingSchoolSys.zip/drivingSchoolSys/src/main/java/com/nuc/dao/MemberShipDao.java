package com.nuc.dao;

import java.util.Map;

import com.nuc.model.MemberShipEntity;

/**
 * Created by tb on 2016/10/30.
 */
public  interface MemberShipDao {

    /**
     * desc 用户登录
     * @param map
     * @return
     */
    MemberShipEntity login(Map<String ,Object> map);


    /**
     * desc 删除指定用户所有角色
     * @param userId
     * @return
     */
    int deletAllRoleById(String userId);
    
    /**
     * desc 添加用户权限
     * @param userRole
     * @return
     */
    int add(MemberShipEntity memberShip);
    
    /**
     * desc 通过用户ID获取
     * @param userId
     * @return
     */
    MemberShipEntity getMemberShipEntityByUserid(String userId);
}
