package com.nuc.dao;

import java.util.List;
import java.util.Map;

import com.nuc.model.FunctionEntity;

/**
* @author HowardAllen
* @version 2019年4月10日 下午7:11:18
* Disc 处理资源类接口
*/

public interface FunctionDao {
	
	/**
	 * 获取资源信息
	 * @param entity
	 * @return
	 */
	public List<FunctionEntity> selectFunction(Map<String, Object> map);
	
	/**
	 * 获取资源记录条数
	 * @param map
	 * @return
	 */
	public Long getTotal(Map<String, Object> map);

	/**
	 * 添加资源信息
	 * @param entity
	 * @return
	 */
	public int insertFunction(FunctionEntity entity);
	
	/**
	 * 更新资源信息
	 * @param entity
	 * @return
	 */
	public int updateFunction(FunctionEntity entity);
	
	/**
	 * 删除资源信息
	 * @param funId
	 * @return
	 */
	public int deleteFunction(int funId);
	
}
