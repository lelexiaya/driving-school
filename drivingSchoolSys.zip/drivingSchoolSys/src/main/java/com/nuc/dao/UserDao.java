package com.nuc.dao;

import java.util.List;
import java.util.Map;

import com.nuc.model.UserEntity;

/**
 * 用户DAO
 * Created by tb on 2016/10/29.
 */

 public interface UserDao {

    /**
     * desc 通过id查询用户实体
     * @param id
     * @return
     */
     UserEntity findById(String id);
     
     /**
      * 通过username查询用户信息
      * @param username
      * @return
      */
     UserEntity findByUsername(String username);

    /**
     * 根据条件查询用户集合
     * @param map
     * @return
     */
	List<UserEntity> find(Map<String ,Object> map);
	
    /**
     * 获取总记录数
     * @param map
     * @return
     */
	Long getTotal(Map<String,Object> map);

    /**
     * 修改用户
     * @param user
     * @return
     */
	int update(UserEntity user);

    /**
     * 添加用户
     * @param user
     * @return
     */
	int add(UserEntity user);

    /**
     * 删除用户
     * @param id
     * @return
     */
	int delete(String usreId);
	
	/**
	 * 获取专业列表
	 * @param map
	 * @return
	 */
	List<UserEntity> getCollageList(Map<String, Object> map);
	
	/**
	 * 获取班级列表
	 * @param map
	 * @return
	 */
	List<UserEntity> getClassIdList(Map<String, Object> map);
	
	/**
	 * desc 获取教师信息，通过classID
	 * @param classId
	 * @return
	 */
	UserEntity getTeacherInfoByStudentId(String classId);
	
	/**
	 * 获取用户信息通过角色名称
	 * @param map
	 * @return
	 */
	List<UserEntity> getUserInfoByRoleName(Map<String, Object> map);
	
	boolean uploadDate(String filePath);
	
	boolean uploadDateRole(String filePath);
	
}
