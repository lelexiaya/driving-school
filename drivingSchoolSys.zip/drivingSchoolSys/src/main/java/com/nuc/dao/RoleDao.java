package com.nuc.dao;

import java.util.List;
import java.util.Map;

import com.nuc.model.RoleEntity;

/**
* @author HowardAllen
* @version 2019年4月6日 上午11:48:52
* Disc 处理角色的Dao层接口
*/

public interface RoleDao {

	/**
	 * 查询角色信息
	 * @param map 分页信息，为空默认不分页
	 * @return
	 */
	List<RoleEntity> findByPage(Map<String, Object> map);
	
	/**
	 * 通过角色ID查询角色信息
	 * @param roleId
	 * @return
	 */
	RoleEntity findById(String roleId);
	
	/**
	 * desc 通过用户ID查询角色信息
	 * @param userId
	 * @return
	 */
	List<RoleEntity> findByUserId(Integer userId);
	
	/**
	 * 通过角色名来查询角色信息
	 * @param roleName
	 * @return
	 */
	RoleEntity findByRoleName(String roleName);
	
	/**
	 * 查询角色记录条数
	 * @param map
	 * @return
	 */
	Long getTotal(Map<String, Object> map);
	
	/**
	 * 添加角色信息
	 * @param entity
	 * @return
	 */
	int addRole(RoleEntity entity);
	
	/**
	 * 修改角色信息
	 * @param entity
	 * @return
	 */
	int updateRole(RoleEntity entity);
	
	
	/**
	 * 删除角色
	 * @param id
	 * @return
	 */
	int deleteRole(String id);
}
