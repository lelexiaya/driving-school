package com.nuc.dao;

import java.util.List;
import java.util.Map;

import com.nuc.model.AppointmentInfo;

public interface AppointmentInfoDao {
    int deleteByPrimaryKey(String appointmentId);

    int insert(AppointmentInfo record);

    int insertSelective(AppointmentInfo record);

    AppointmentInfo selectByPrimaryKey(String appointmentId);
    
    List<AppointmentInfo> selectAppointment(Map<String, Object> map);

    int updateByPrimaryKeySelective(AppointmentInfo record);

    int updateByPrimaryKey(AppointmentInfo record);
    
    Long getTotal(Map<String, Object> map);
    
    List<String> getAppointmentNum(String appointmentId);
    
    int addUserAppointment(Map<String, Object> map);
    
    int delUserAppointment(Map<String, Object> map);
    
    List<String> getAppointmentNumByUserId(Integer userId);
}